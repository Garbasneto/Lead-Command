# Lead Command · Hub Performance

Pacote inicial para construir o Lead Command no Claude Code.

- CLAUDE.md: instruções permanentes do projeto. O Claude Code lê sozinho no começo de cada sessão.
- docs/ESPECIFICACAO.md: produto, dados, inteligência e fases.
- docs/VISUAL.md: direção visual.
- prototipo/hub-lead-command.html: protótipo atual, abre direto no navegador.
- PRIMEIRO-PROMPT.md: a primeira mensagem para colar no Claude Code.

Para começar: suba esta pasta num repositório do GitHub (ou abra a pasta no Claude Code do app para Mac) e cole o conteúdo do PRIMEIRO-PROMPT.md na primeira mensagem.
